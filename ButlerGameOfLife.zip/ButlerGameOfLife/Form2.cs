﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ButlerGameOfLife
{
    public partial class Form2 : Form
    {
        public static int xf2, yf2;
        public Form2()
        {
            InitializeComponent();
        }

        private void numericHeight_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericWidth_ValueChanged(object sender, EventArgs e)
        {

        }

        private void HeightTextBox_Click(object sender, EventArgs e)
        {

        }

        private void DoneButton_Click(object sender, EventArgs e)
        {
            decimal hdec = numericHeight.Value;
            int hint = Convert.ToInt32(hdec);

            decimal wdec = numericWidth.Value;
            int wint = Convert.ToInt32(wdec);

            if (DoneButton.Enabled == true)
            {
                xf2 = hint;
                yf2 = wint;
                //MessageBox.Show("testing");
                
                Close();
            }
        }
    }
}
